<?php

require_once('kapcsolat.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    //átjöttek-e az adatok?
    if (isset($_POST['klan'])) {
        $klan = $_POST['klan'];
       

        $sql = "SELECT torpek.nev AS 'torpe_nev', 
                       SUM(kihol.kitermelt_mennyiseg) AS 'kitermelt_mennyiseg'
                FROM torpek, kihol
                WHERE torpek.id = kihol.torpe_id AND torpek.klan LIKE '$klan'
                GROUP BY torpek.id;";
        
        $result = mysqli_query($conn, $sql);

        //ellenőrzés, jöttek vissza adatok? (törpék)
        if (mysqli_num_rows($result) > 0) {
            $torpek=[];
            while($row = mysqli_fetch_assoc($result)) { //$row egy törpe adatát tartalmazz, "torpe_nev" és "kitermelt_mennyiseg" kulcsokon (SELECT-ben ezek az attribútumok vannak megadva)
                $torpek[] = $row;
            }
            //rendelkezésre áll az összes adat
            http_response_code(200);
            header('Content-Type: application/json');
            echo json_encode($torpek);
        }
    }
}