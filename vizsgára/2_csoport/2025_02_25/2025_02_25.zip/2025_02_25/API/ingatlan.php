<?php

require_once('kapcsolat.php');

if ($_SERVER['REQUEST_METHOD'] === "GET") {
    
    $sql = "SELECT ingatlanok.id, kategoriak.nev AS 'kategoria',
                   ingatlanok.leiras, ingatlanok.hirdetesDatuma,
                   ingatlanok.tehermentes, ingatlanok.ar, ingatlanok.kepUrl
            FROM ingatlanok, kategoriak
            WHERE kategoriak.id = ingatlanok.kategoria_id;";
    //futtatás
    $result = mysqli_query($conn, $sql);

    //ellenőrzés: jöttek e vissza adatok (sorok)
    if (mysqli_num_rows($result) > 0) {
        //a kapott ingatlanokat beletesszük egy tömbbe
        $ingatlanok = [];
        //kinyerjük a visszakapott sorokat a $result változóból
        while ($row = mysqli_fetch_assoc($result)) { //$row egy ingatlan adatait tartalmazza
           $ingatlanok[] = $row;
        }
        //rendelkezésünkre áll az összes ingatlan a $ingatlanok tömbbe
        http_response_code(200); //ok
        header("Content-Type: application/json");
        echo json_encode($ingatlanok);
    }
}
if ($_SERVER['REQUEST_METHOD'] === "POST") {
    //ELLENŐRZÉS: MEGÉRKEZTEK-E AZ ADATOK A FRONTENDTŐL
    if (isset($_POST['kategoria'], $_POST['leiras'], $_POST['hirdetesDatuma'], 
              $_POST['tehermentes'], $_POST['ar'], $_POST['kepUrl'])) 
    {
        //adatok átvétele változóba:
        $kat = $_POST['kategoria'];
        $leiras = $_POST['leiras'];
        $datum = $_POST['hirdetesDatuma'];
        $tehermentes = $_POST['tehermentes'];
        $ar = $_POST['ar'];
        $url = $_POST['kepUrl'];

        $sql = "INSERT INTO ingatlanok (kategoria_id, leiras, hirdetesDatuma, tehermentes, ar, kepUrl)
                VALUES ($kat, $leiras, $datum, $tehermentes, $ar, $url)";
        
        $result = mysqli_query($conn, $sql);

        if ($result) { //mivel nem jöttek sorok, csak azt kell megnézni, hogy a $result igaz-e
            http_response_code(200);
            echo "Sikeres feltöltés";
        }
        else{ //$result = NULL --> nem sikerült beszúrni az adatokat
            http_response_code(404);
            echo "Hiányos adatok";
        }

    }

}