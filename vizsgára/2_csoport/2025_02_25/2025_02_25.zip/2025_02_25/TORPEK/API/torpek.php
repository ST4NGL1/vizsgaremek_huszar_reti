<?php
require_once('kapcsolat.php');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {

    $sql = "SELECT * FROM torpek";

    $result = mysqli_query($conn, $sql);

    if(mysqli_num_rows($result) > 0){
        $torpek = [];
        while($row = mysqli_fetch_assoc($result)){
            $torpek[] = $row;
        }
        http_response_code(200);
        header('Content-Type: application/json');
        echo json_encode($torpek);
    }
}